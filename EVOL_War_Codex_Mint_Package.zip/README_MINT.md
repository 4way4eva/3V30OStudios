# EVOL War Codex — Mint Package

Chain: Avalanche C-Chain (chainId 43114)
Contract (example): 0x638f2c25dc4346dbef5566a2d5da871f6d268b8a

## Files
- EvolVerse_War_Codex_Scroll_SEALED.pdf
- EvolVerse_War_Codex_Scroll.seal.json
- EvolVerse_War_Codex_Scroll.md
- EVOL_War_Codex_ENFT_Metadata.json
- erc721.metadata.json
- erc1155.metadata.json
- erc721.abi.json
- erc1155.abi.json
- calldata.template.json

## 1) Pin to IPFS (CLI)
ipfs add -r ./EVOL_War_Codex_Mint_Package

Take the directory CID and replace {REPLACE_WITH_IPFS_CID} in the metadata and calldata templates.

Alternatively (Pinata API pseudo):
curl -X POST -H "Authorization: Bearer <PINATA_JWT>" -F file=@EVOL_War_Codex_Mint_Package.zip https://api.pinata.cloud/pinning/pinFileToIPFS

## 2) Update metadata URIs
- erc721.metadata.json -> animation_url/external_url should point to ipfs://<CID>/... files.
- For ERC-721, host the metadata JSON itself at ipfs://<CID>/erc721.metadata.json and pass that URI to the mint.

## 3) Mint examples (ethers.js)
const [signer] = await ethers.getSigners();
const to = "0xYourRecipientAddress";
const cid = "<IPFS_DIR_CID>";
const tokenURI = `ipfs://${cid}/erc721.metadata.json`;
const nft = await ethers.getContractAt(require('./erc721.abi.json'), "0x638f2c25dc4346dbef5566a2d5da871f6d268b8a");
await nft.safeMint(to, tokenURI);

## 4) Verify
- Compare sha256 of the on-chain referenced PDF with EvolVerse_War_Codex_Scroll_SHA256.txt.

## Ethics & Compliance
- Lawful use only. No infringement. No civilian harm.