# Deploy Configs v0.1

Targets: Sepolia (11155111), Polygon Amoy (80002), Avalanche Fuji (43113)

1) Copy .env.example to .env and fill RPC, PRIVATE_KEY, explorer keys, CASCADE_ADDRESS.
2) Install deps: npm i
3) Compile: npm run compile
4) Deploy:
   npm run deploy:sepolia
   npm run deploy:amoy
   npm run deploy:fuji
5) Verify (optional):
   npm run verify:sepolia <ENFT_ADDRESS> --constructor-args <cascade>
   npm run verify:amoy <ENFT_ADDRESS> --constructor-args <cascade>
   npm run verify:fuji <ENFT_ADDRESS> --constructor-args <cascade>
6) Mint test:
   MINT_TO=0xYourAddr MINT_URI=ipfs://... CASCADE_PAYLOAD=0x npm run mint -- sepolia

Watchtower:
- config/Watchtower_Thresholds.json governs τ, latency, thermal limits and course depth.
- Enforce pre-mint checks in your backend or Watchtower agent before calling mint.
