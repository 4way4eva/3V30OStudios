import fs from 'fs';
import path from 'path';

export function saveDeployment(network: string, name: string, address: string, abi: any) {
  const dir = path.join('deployments', network);
  fs.mkdirSync(dir, { recursive: true });
  const f = path.join(dir, name + '.json');
  const payload = { name, address, abi, updatedAt: new Date().toISOString() };
  fs.writeFileSync(f, JSON.stringify(payload, null, 2));
  console.log('Saved', f);
}
