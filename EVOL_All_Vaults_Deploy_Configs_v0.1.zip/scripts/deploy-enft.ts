import { ethers, network, artifacts } from "hardhat";
import { saveDeployment } from "./utils/saveDeployment";

async function main() {
  const cascade = process.env.CASCADE_ADDRESS || ethers.ZeroAddress;
  const [deployer] = await ethers.getSigners();
  console.log("Deployer:", deployer.address);
  console.log("Network:", network.name);
  console.log("Cascade:", cascade);

  const ENFT = await ethers.getContractFactory("ENFTMint");
  const enft = await ENFT.deploy(cascade);
  await enft.waitForDeployment();
  const addr = await enft.getAddress();
  console.log("ENFTMint:", addr);

  const art = await artifacts.readArtifact("ENFTMint");
  saveDeployment(network.name, "ENFTMint", addr, art.abi);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
