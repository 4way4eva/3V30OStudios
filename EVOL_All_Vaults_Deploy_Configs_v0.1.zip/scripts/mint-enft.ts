import { ethers, network } from "hardhat";
import fs from "fs";
import path from "path";

async function main() {
  const to = process.env.MINT_TO;
  const tokenURI = process.env.MINT_URI || "ipfs://example";
  const cascadePayloadHex = process.env.CASCADE_PAYLOAD || "0x";
  if (!to) throw new Error("MINT_TO is required");

  const f = path.join("deployments", network.name, "ENFTMint.json");
  const { address, abi } = JSON.parse(fs.readFileSync(f, "utf-8"));
  const [signer] = await ethers.getSigners();
  const enft = new ethers.Contract(address, abi, signer);

  const tx = await enft.mint(to, tokenURI, cascadePayloadHex as any);
  const rc = await tx.wait();
  console.log("Mint tx:", rc?.hash);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
